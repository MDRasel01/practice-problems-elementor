<?php
/**
 * Custom Post Type & Taxonomies for Practice Problems.
 *
 * @package PracticeProblems
 */

namespace PracticeProblems;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CPT
 */
class CPT {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'register_post_type' ] );
		add_action( 'init', [ $this, 'register_taxonomies' ] );
		add_action( 'add_meta_boxes', [ $this, 'add_meta_boxes' ] );
		add_action( 'save_post_practice_problem', [ $this, 'save_meta_boxes' ] );
	}

	/**
	 * Register Custom Post Type.
	 */
	public function register_post_type() {
		$labels = [
			'name'               => _x( 'Practice Problems', 'post type general name', 'practice-problems-el' ),
			'singular_name'      => _x( 'Practice Problem', 'post type singular name', 'practice-problems-el' ),
			'menu_name'          => _x( 'Practice Problems', 'admin menu', 'practice-problems-el' ),
			'name_admin_bar'     => _x( 'Practice Problem', 'add new on admin bar', 'practice-problems-el' ),
			'add_new'            => _x( 'Add New', 'practice problem', 'practice-problems-el' ),
			'add_new_item'       => __( 'Add New Practice Problem', 'practice-problems-el' ),
			'new_item'           => __( 'New Practice Problem', 'practice-problems-el' ),
			'edit_item'          => __( 'Edit Practice Problem', 'practice-problems-el' ),
			'view_item'          => __( 'View Practice Problem', 'practice-problems-el' ),
			'all_items'          => __( 'All Practice Problems', 'practice-problems-el' ),
			'search_items'       => __( 'Search Practice Problems', 'practice-problems-el' ),
			'not_found'          => __( 'No practice problems found.', 'practice-problems-el' ),
			'not_found_in_trash' => __( 'No practice problems found in Trash.', 'practice-problems-el' ),
		];

		$args = [
			'labels'             => $labels,
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => [ 'slug' => 'practice-problem' ],
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => 25,
			'menu_icon'          => 'dashicons-welcome-learn-more',
			'supports'           => [ 'title', 'editor', 'excerpt', 'custom-fields' ],
			'show_in_rest'       => true,
		];

		register_post_type( 'practice_problem', $args );
	}

	/**
	 * Register Taxonomies.
	 */
	public function register_taxonomies() {
		// Topic Taxonomy.
		register_taxonomy(
			'problem_topic',
			'practice_problem',
			[
				'hierarchical'      => true,
				'labels'            => [
					'name'          => __( 'Topics', 'practice-problems-el' ),
					'singular_name' => __( 'Topic', 'practice-problems-el' ),
					'search_items'  => __( 'Search Topics', 'practice-problems-el' ),
					'all_items'     => __( 'All Topics', 'practice-problems-el' ),
					'edit_item'     => __( 'Edit Topic', 'practice-problems-el' ),
					'update_item'   => __( 'Update Topic', 'practice-problems-el' ),
					'add_new_item'  => __( 'Add New Topic', 'practice-problems-el' ),
					'new_item_name' => __( 'New Topic Name', 'practice-problems-el' ),
					'menu_name'     => __( 'Topics', 'practice-problems-el' ),
				],
				'show_ui'           => true,
				'show_admin_column' => true,
				'query_var'         => true,
				'rewrite'           => [ 'slug' => 'problem-topic' ],
				'show_in_rest'      => true,
			]
		);

		// Difficulty Taxonomy.
		register_taxonomy(
			'problem_difficulty',
			'practice_problem',
			[
				'hierarchical'      => true,
				'labels'            => [
					'name'          => __( 'Difficulties', 'practice-problems-el' ),
					'singular_name' => __( 'Difficulty', 'practice-problems-el' ),
					'search_items'  => __( 'Search Difficulties', 'practice-problems-el' ),
					'all_items'     => __( 'All Difficulties', 'practice-problems-el' ),
					'edit_item'     => __( 'Edit Difficulty', 'practice-problems-el' ),
					'update_item'   => __( 'Update Difficulty', 'practice-problems-el' ),
					'add_new_item'  => __( 'Add New Difficulty', 'practice-problems-el' ),
					'new_item_name' => __( 'New Difficulty Name', 'practice-problems-el' ),
					'menu_name'     => __( 'Difficulties', 'practice-problems-el' ),
				],
				'show_ui'           => true,
				'show_admin_column' => true,
				'query_var'         => true,
				'rewrite'           => [ 'slug' => 'problem-difficulty' ],
				'show_in_rest'      => true,
			]
		);
	}

	/**
	 * Add Meta Boxes for Problem Details.
	 */
	public function add_meta_boxes() {
		add_meta_box(
			'pp_problem_details',
			__( 'Problem Details & Solution', 'practice-problems-el' ),
			[ $this, 'render_meta_box' ],
			'practice_problem',
			'normal',
			'high'
		);
	}

	/**
	 * Render Meta Box.
	 *
	 * @param \WP_Post $post Current post.
	 */
	public function render_meta_box( $post ) {
		wp_nonce_field( 'pp_save_problem_meta', 'pp_problem_meta_nonce' );

		$problem_id = get_post_meta( $post->ID, '_pp_problem_id', true );
		$steps      = get_post_meta( $post->ID, '_pp_steps', true );
		$answer     = get_post_meta( $post->ID, '_pp_answer', true );
		?>
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row"><label for="pp_problem_id"><?php esc_html_e( 'Problem ID Badge Text', 'practice-problems-el' ); ?></label></th>
					<td>
						<input type="text" id="pp_problem_id" name="pp_problem_id" value="<?php echo esc_attr( $problem_id ? $problem_id : $post->ID ); ?>" class="regular-text" />
						<p class="description"><?php esc_html_e( 'Display number or badge for this problem (e.g. 1, 2, or EX-101).', 'practice-problems-el' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="pp_steps"><?php esc_html_e( 'Step-by-Step Solution', 'practice-problems-el' ); ?></label></th>
					<td>
						<textarea id="pp_steps" name="pp_steps" rows="6" class="large-text code"><?php echo esc_textarea( $steps ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Enter one step per line, or JSON array of steps.', 'practice-problems-el' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="pp_answer"><?php esc_html_e( 'Final Answer', 'practice-problems-el' ); ?></label></th>
					<td>
						<input type="text" id="pp_answer" name="pp_answer" value="<?php echo esc_attr( $answer ); ?>" class="large-text" />
						<p class="description"><?php esc_html_e( 'Final short answer, formula, or result.', 'practice-problems-el' ); ?></p>
					</td>
				</tr>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Save Meta Box data.
	 *
	 * @param int $post_id Post ID.
	 */
	public function save_meta_boxes( $post_id ) {
		if ( ! isset( $_POST['pp_problem_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['pp_problem_meta_nonce'] ) ), 'pp_save_problem_meta' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( isset( $_POST['pp_problem_id'] ) ) {
			update_post_meta( $post_id, '_pp_problem_id', sanitize_text_field( wp_unslash( $_POST['pp_problem_id'] ) ) );
		}

		if ( isset( $_POST['pp_steps'] ) ) {
			update_post_meta( $post_id, '_pp_steps', sanitize_textarea_field( wp_unslash( $_POST['pp_steps'] ) ) );
		}

		if ( isset( $_POST['pp_answer'] ) ) {
			update_post_meta( $post_id, '_pp_answer', wp_kses_post( wp_unslash( $_POST['pp_answer'] ) ) );
		}
	}
}
